<h2>Védett fajok statisztikája</h2>
<h2>Nem védett fajok statisztikája</h2>